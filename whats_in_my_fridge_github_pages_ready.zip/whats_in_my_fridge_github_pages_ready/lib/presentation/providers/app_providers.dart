import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/data/repositories/demo_inventory_repository.dart';
import 'package:whats_in_my_fridge/data/repositories/firestore_inventory_repository.dart';
import 'package:whats_in_my_fridge/data/services/ai_service.dart';
import 'package:whats_in_my_fridge/data/services/auth_service.dart';
import 'package:whats_in_my_fridge/data/services/firebase_bootstrap.dart';
import 'package:whats_in_my_fridge/data/services/image_storage_service.dart';
import 'package:whats_in_my_fridge/data/services/notification_service.dart';
import 'package:whats_in_my_fridge/domain/entities/detected_food.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/domain/entities/meal_plan_entry.dart';
import 'package:whats_in_my_fridge/domain/entities/recipe.dart';
import 'package:whats_in_my_fridge/domain/entities/shopping_item.dart';
import 'package:whats_in_my_fridge/domain/repositories/inventory_repository.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());
final aiServiceProvider = Provider<AiService>((ref) => AiService());
final imageStorageServiceProvider = Provider<ImageStorageService>((ref) => ImageStorageService());
final notificationServiceProvider = Provider<NotificationService>((ref) => NotificationService());
final demoInventoryRepositoryProvider = Provider<DemoInventoryRepository>(
  (ref) => DemoInventoryRepository(),
);

final authControllerProvider =
    AsyncNotifierProvider<AuthController, AppAuthState>(AuthController.new);

class AuthController extends AsyncNotifier<AppAuthState> {
  AuthService get _service => ref.read(authServiceProvider);

  @override
  Future<AppAuthState> build() async => _service.currentState();

  Future<void> signIn(String email, String password) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _service.signIn(email, password));
  }

  Future<void> signUp(String email, String password, String name) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _service.signUp(email, password, name));
  }

  Future<void> signInWithGoogle() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_service.signInWithGoogle);
  }

  Future<void> signInWithApple() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_service.signInWithApple);
  }

  Future<void> resetPassword(String email) => _service.resetPassword(email);

  Future<void> signOut() async {
    await _service.signOut();
    state = const AsyncData(AppAuthState.signedOut());
  }
}

final inventoryRepositoryProvider = Provider<InventoryRepository>((ref) {
  final auth = ref.watch(authControllerProvider).asData?.value;
  if (FirebaseBootstrap.isReady && auth?.uid != null && auth?.isDemo == false) {
    return FirestoreInventoryRepository(
      firestore: FirebaseFirestore.instance,
      uid: auth!.uid!,
    );
  }
  return ref.watch(demoInventoryRepositoryProvider);
});

final inventoryProvider =
    AsyncNotifierProvider<InventoryController, List<FoodItem>>(
  InventoryController.new,
);

class InventoryController extends AsyncNotifier<List<FoodItem>> {
  InventoryRepository get _repository => ref.read(inventoryRepositoryProvider);

  @override
  Future<List<FoodItem>> build() async {
    final repository = ref.watch(inventoryRepositoryProvider);
    return repository.getItems();
  }

  Future<void> save(FoodItem item) async {
    await _repository.saveItem(item);
    final current = [...?state.asData?.value];
    final index = current.indexWhere((value) => value.id == item.id);
    if (index == -1) {
      current.insert(0, item);
    } else {
      current[index] = item;
    }
    state = AsyncData(current);
  }

  Future<void> delete(String id) async {
    await _repository.deleteItem(id);
    state = AsyncData(
      [...?state.asData?.value]..removeWhere((item) => item.id == id),
    );
  }

  Future<void> addDetected(List<DetectedFood> foods) async {
    for (final food in foods.where((item) => item.selected)) {
      final now = DateTime.now();
      await save(
        FoodItem(
          id: '${food.name}-${now.microsecondsSinceEpoch}',
          name: food.name,
          category: food.category,
          quantity: 1,
          unit: 'pcs',
          purchaseDate: now,
          expirationDate: now.add(const Duration(days: 7)),
          storageLocation: 'Fridge',
          notes: 'Added with AI recognition',
          createdAt: now,
        ),
      );
    }
  }
}

final recipeFiltersProvider =
    NotifierProvider<RecipeFiltersController, Set<String>>(
  RecipeFiltersController.new,
);

class RecipeFiltersController extends Notifier<Set<String>> {
  @override
  Set<String> build() => <String>{};

  void toggle(String value) {
    state = state.contains(value)
        ? ({...state}..remove(value))
        : {...state, value};
  }
}

final recipesProvider = AsyncNotifierProvider<RecipesController, List<Recipe>>(
  RecipesController.new,
);

class RecipesController extends AsyncNotifier<List<Recipe>> {
  @override
  Future<List<Recipe>> build() async {
    final inventory = await ref.watch(inventoryProvider.future);
    final filters = ref.watch(recipeFiltersProvider);
    return ref.read(aiServiceProvider).generateRecipes(
          inventory: inventory,
          filters: filters,
        );
  }

  void toggleFavorite(String id) {
    final recipes = state.asData?.value;
    if (recipes == null) return;
    state = AsyncData([
      for (final recipe in recipes)
        if (recipe.id == id)
          recipe.copyWith(isFavorite: !recipe.isFavorite)
        else
          recipe,
    ]);
  }

}

final shoppingProvider =
    NotifierProvider<ShoppingController, List<ShoppingItem>>(
  ShoppingController.new,
);

class ShoppingController extends Notifier<List<ShoppingItem>> {
  @override
  List<ShoppingItem> build() => const [
        ShoppingItem(
          id: 'onion',
          name: 'Onions',
          quantity: '3',
          reason: 'Frequently purchased',
        ),
        ShoppingItem(
          id: 'garlic',
          name: 'Garlic',
          quantity: '1 bulb',
          reason: 'Missing for recipe',
        ),
      ];

  void add(String name, {String reason = 'Manual'}) {
    state = [
      ...state,
      ShoppingItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        name: name,
        reason: reason,
      ),
    ];
  }

  void toggle(String id) {
    state = [
      for (final item in state)
        if (item.id == id) item.copyWith(checked: !item.checked) else item,
    ];
  }

  void removeChecked() => state = state.where((item) => !item.checked).toList();

  void generateFromInventory(List<FoodItem> inventory) {
    final existing = state.map((item) => item.name.toLowerCase()).toSet();
    final lowStock = inventory.where((item) => item.quantity <= 1).where((item) => !existing.contains(item.name.toLowerCase()));
    state = [
      ...state,
      ...lowStock.map((item) => ShoppingItem(
            id: 'low-${item.id}',
            name: item.name,
            reason: 'Low inventory',
          )),
    ];
  }

  void addMissingIngredients(Recipe recipe) {
    final existing = state.map((item) => item.name.toLowerCase()).toSet();
    final additions = recipe.missingIngredients
        .where((name) => !existing.contains(name.toLowerCase()))
        .map(
          (name) => ShoppingItem(
            id: '$name-${DateTime.now().microsecondsSinceEpoch}',
            name: name,
            reason: 'Missing for ${recipe.title}',
          ),
        );
    state = [...state, ...additions];
  }
}

final mealPlanProvider =
    NotifierProvider<MealPlanController, List<MealPlanEntry>>(
  MealPlanController.new,
);

class MealPlanController extends Notifier<List<MealPlanEntry>> {
  @override
  List<MealPlanEntry> build() => const [];

  void add(DateTime date, Recipe recipe, {String mealType = 'Dinner'}) {
    state = [
      ...state.where(
        (entry) => !(DateUtils.isSameDay(entry.date, date) &&
            entry.mealType == mealType),
      ),
      MealPlanEntry(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        date: date,
        mealType: mealType,
        recipe: recipe,
      ),
    ];
  }

  void remove(String id) =>
      state = state.where((entry) => entry.id != id).toList();
}

final themeModeProvider = NotifierProvider<ThemeModeController, ThemeMode>(
  ThemeModeController.new,
);

class ThemeModeController extends Notifier<ThemeMode> {
  @override
  ThemeMode build() => ThemeMode.system;
  void set(ThemeMode mode) => state = mode;
}

final dietaryPreferencesProvider =
    NotifierProvider<DietaryPreferencesController, Set<String>>(
  DietaryPreferencesController.new,
);

class DietaryPreferencesController extends Notifier<Set<String>> {
  @override
  Set<String> build() => <String>{};
  void toggle(String preference) {
    state = state.contains(preference)
        ? ({...state}..remove(preference))
        : {...state, preference};
  }
}

final aiRecognitionProvider =
    AsyncNotifierProvider<AiRecognitionController, List<DetectedFood>>(
  AiRecognitionController.new,
);

class AiRecognitionController extends AsyncNotifier<List<DetectedFood>> {
  @override
  Future<List<DetectedFood>> build() async => const [];

  Future<void> analyze(Uint8List bytes) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(
      () => ref.read(aiServiceProvider).recognizeFoods(bytes),
    );
  }

  void toggle(int index) {
    final current = [...?state.asData?.value];
    if (index < 0 || index >= current.length) return;
    current[index] = current[index].copyWith(selected: !current[index].selected);
    state = AsyncData(current);
  }

  void clear() => state = const AsyncData([]);
}
