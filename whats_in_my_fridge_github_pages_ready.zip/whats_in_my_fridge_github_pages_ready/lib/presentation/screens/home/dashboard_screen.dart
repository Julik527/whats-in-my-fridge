import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/utils/date_formatters.dart';
import 'package:whats_in_my_fridge/core/widgets/app_card.dart';
import 'package:whats_in_my_fridge/core/widgets/section_header.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';
import 'package:whats_in_my_fridge/presentation/widgets/stat_card.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final inventory = ref.watch(inventoryProvider);
    final recipes = ref.watch(recipesProvider);
    final session = ref.watch(authControllerProvider).asData?.value;

    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(inventoryProvider);
        ref.invalidate(recipesProvider);
      },
      child: inventory.when(
        loading: () => const ListView(
          physics: AlwaysScrollableScrollPhysics(),
          children: [SizedBox(height: 280), Center(child: CircularProgressIndicator())],
        ),
        error: (error, stackTrace) => ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(24),
          children: [Text('Could not load inventory: $error')],
        ),
        data: (items) {
          final expiring = [...items]
            ..sort((a, b) => a.expirationDate.compareTo(b.expirationDate));
          final recent = [...items]
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
          final today = items.where((item) => item.expiresToday).length;
          final week = items.where((item) => item.expiresThisWeek).length;
          final favorites = recipes.asData?.value
                  .where((recipe) => recipe.isFavorite)
                  .length ??
              0;

          return ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
            children: [
              Text(
                'Hi ${session?.displayName?.split(' ').first ?? 'there'} 👋',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'Here is what needs your attention today.',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              if (session?.isDemo == true) ...[
                const SizedBox(height: 14),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: const Row(
                    children: [
                      Icon(Icons.science_outlined),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text('Demo mode is active. Connect Firebase to sync real data.'),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 22),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.18,
                children: [
                  StatCard(
                    icon: Icons.inventory_2_outlined,
                    value: '${items.length}',
                    label: 'Total items',
                  ),
                  StatCard(
                    icon: Icons.today_rounded,
                    value: '$today',
                    label: 'Expire today',
                    emphasized: today > 0,
                  ),
                  StatCard(
                    icon: Icons.date_range_rounded,
                    value: '$week',
                    label: 'This week',
                  ),
                  StatCard(
                    icon: Icons.favorite_outline_rounded,
                    value: '$favorites',
                    label: 'Favorite recipes',
                  ),
                ],
              ),
              const SizedBox(height: 28),
              const SectionHeader(title: 'Expiration timeline'),
              const SizedBox(height: 12),
              AppCard(
                child: Column(
                  children: [
                    for (var index = 0; index < expiring.take(5).length; index++) ...[
                      _ExpiryRow(item: expiring[index]),
                      if (index < expiring.take(5).length - 1) const Divider(height: 24),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const SectionHeader(title: 'Recently added'),
              const SizedBox(height: 12),
              SizedBox(
                height: 148,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: recent.take(5).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) {
                    final item = recent[index];
                    return SizedBox(
                      width: 150,
                      child: AppCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.category.emoji, style: const TextStyle(fontSize: 30)),
                            const Spacer(),
                            Text(
                              item.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.w700,
                                  ),
                            ),
                            const SizedBox(height: 4),
                            Text('${item.quantity} ${item.unit}'),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ExpiryRow extends StatelessWidget {
  const _ExpiryRow({required this.item});

  final FoodItem item;

  @override
  Widget build(BuildContext context) {
    final days = item.daysUntilExpiration;
    final scheme = Theme.of(context).colorScheme;
    final label = switch (days) {
      < 0 => 'Expired',
      0 => 'Today',
      1 => 'Tomorrow',
      _ => 'In $days days',
    };
    final urgent = days <= 1;

    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: urgent ? scheme.errorContainer : scheme.secondaryContainer,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(item.category.emoji, style: const TextStyle(fontSize: 23)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text('${item.storageLocation} · ${shortDate(item.expirationDate)}'),
            ],
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: urgent ? scheme.error : scheme.primary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
