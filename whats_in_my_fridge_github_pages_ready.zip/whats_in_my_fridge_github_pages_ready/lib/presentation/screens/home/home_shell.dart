import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';
import 'package:whats_in_my_fridge/presentation/screens/home/dashboard_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/inventory/food_form_sheet.dart';
import 'package:whats_in_my_fridge/presentation/screens/inventory/inventory_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/more/assistant_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/more/more_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/planner/planner_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/recipes/recipes_screen.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});

  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final session = ref.read(authControllerProvider).asData?.value;
      final uid = session?.uid;
      if (uid != null && session?.isDemo == false) {
        ref.read(notificationServiceProvider).registerForUser(uid);
      }
    });
  }

  static const _titles = [
    'Overview',
    'Inventory',
    'Recipes',
    'Meal planner',
    'More',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: Text(_titles[_index], key: ValueKey(_index)),
        ),
        actions: [
          IconButton(
            tooltip: 'AI assistant',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const AssistantScreen(),
              ),
            ),
            icon: const Icon(Icons.auto_awesome_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: const [
          DashboardScreen(),
          InventoryScreen(),
          RecipesScreen(),
          PlannerScreen(),
          MoreScreen(),
        ],
      ),
      floatingActionButton: _index == 1
          ? FloatingActionButton.extended(
              onPressed: () => showFoodFormSheet(context),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add food'),
            )
          : _index == 2
              ? FloatingActionButton.extended(
                  onPressed: () => setState(() => _index = 1),
                  icon: const Icon(Icons.kitchen_rounded),
                  label: const Text('Check inventory'),
                )
              : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            selectedIcon: Icon(Icons.inventory_2_rounded),
            label: 'Inventory',
          ),
          NavigationDestination(
            icon: Icon(Icons.restaurant_menu_outlined),
            selectedIcon: Icon(Icons.restaurant_menu_rounded),
            label: 'Recipes',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_month_outlined),
            selectedIcon: Icon(Icons.calendar_month_rounded),
            label: 'Planner',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'More',
          ),
        ],
      ),
    );
  }
}
