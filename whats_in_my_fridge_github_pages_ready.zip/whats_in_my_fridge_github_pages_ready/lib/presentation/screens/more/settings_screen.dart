import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  String _language = 'English';
  String _units = 'Metric';
  bool _today = true;
  bool _tomorrow = true;
  bool _threeDays = true;

  static const diets = [
    'Vegetarian',
    'Vegan',
    'Gluten-free',
    'High protein',
    'Low carb',
  ];

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeModeProvider);
    final dietary = ref.watch(dietaryPreferencesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          _SectionTitle('Appearance'),
          Card(
            child: Column(
              children: [
                RadioListTile<ThemeMode>(
                  value: ThemeMode.system,
                  groupValue: themeMode,
                  onChanged: (value) =>
                      ref.read(themeModeProvider.notifier).set(value!),
                  title: const Text('System theme'),
                  secondary: const Icon(Icons.brightness_auto_rounded),
                ),
                RadioListTile<ThemeMode>(
                  value: ThemeMode.light,
                  groupValue: themeMode,
                  onChanged: (value) =>
                      ref.read(themeModeProvider.notifier).set(value!),
                  title: const Text('Light'),
                  secondary: const Icon(Icons.light_mode_outlined),
                ),
                RadioListTile<ThemeMode>(
                  value: ThemeMode.dark,
                  groupValue: themeMode,
                  onChanged: (value) =>
                      ref.read(themeModeProvider.notifier).set(value!),
                  title: const Text('Dark'),
                  secondary: const Icon(Icons.dark_mode_outlined),
                ),
              ],
            ),
          ),
          _SectionTitle('Regional'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.language_rounded),
                  title: const Text('Language'),
                  trailing: DropdownButton<String>(
                    value: _language,
                    underline: const SizedBox.shrink(),
                    items: const [
                      DropdownMenuItem(value: 'English', child: Text('English')),
                      DropdownMenuItem(value: 'Deutsch', child: Text('Deutsch')),
                    ],
                    onChanged: (value) => setState(() => _language = value!),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.straighten_rounded),
                  title: const Text('Units'),
                  trailing: DropdownButton<String>(
                    value: _units,
                    underline: const SizedBox.shrink(),
                    items: const [
                      DropdownMenuItem(value: 'Metric', child: Text('Metric')),
                      DropdownMenuItem(value: 'Imperial', child: Text('Imperial')),
                    ],
                    onChanged: (value) => setState(() => _units = value!),
                  ),
                ),
              ],
            ),
          ),
          _SectionTitle('Expiration notifications'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  value: _today,
                  onChanged: (value) => setState(() => _today = value),
                  title: const Text('On expiration day'),
                  secondary: const Icon(Icons.today_rounded),
                ),
                SwitchListTile(
                  value: _tomorrow,
                  onChanged: (value) => setState(() => _tomorrow = value),
                  title: const Text('One day before'),
                  secondary: const Icon(Icons.looks_one_outlined),
                ),
                SwitchListTile(
                  value: _threeDays,
                  onChanged: (value) => setState(() => _threeDays = value),
                  title: const Text('Three days before'),
                  secondary: const Icon(Icons.filter_3_outlined),
                ),
              ],
            ),
          ),
          _SectionTitle('Dietary preferences'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final diet in diets)
                FilterChip(
                  label: Text(diet),
                  selected: dietary.contains(diet),
                  onSelected: (_) => ref
                      .read(dietaryPreferencesProvider.notifier)
                      .toggle(diet),
                ),
            ],
          ),
          _SectionTitle('Data'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.file_download_outlined),
                  title: const Text('Export data'),
                  subtitle: const Text('Inventory, recipes, meal plan and statistics'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Data export requested.')),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined),
                  title: const Text('Privacy and account'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 22, 4, 10),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}
