import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:whats_in_my_fridge/core/widgets/app_card.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class StatisticsScreen extends ConsumerWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final inventory = ref.watch(inventoryProvider).asData?.value ?? const <FoodItem>[];
    final meals = ref.watch(mealPlanProvider).length;
    final savedItems = inventory.where((item) => item.daysUntilExpiration <= 3).length + meals;
    final moneySaved = savedItems * 3.75;
    final categoryCounts = <FoodCategory, int>{};
    for (final item in inventory) {
      categoryCounts[item.category] = (categoryCounts[item.category] ?? 0) + 1;
    }
    final sortedCategories = categoryCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Scaffold(
      appBar: AppBar(title: const Text('Statistics')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Text(
            '${DateFormat.MMMM().format(DateTime.now())} report',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
            children: [
              _Metric(icon: Icons.eco_outlined, value: '$savedItems', label: 'Items rescued'),
              _Metric(
                icon: Icons.savings_outlined,
                value: '€${moneySaved.toStringAsFixed(0)}',
                label: 'Estimated saved',
              ),
              _Metric(icon: Icons.restaurant_outlined, value: '$meals', label: 'Meals planned'),
              _Metric(icon: Icons.delete_outline_rounded, value: '1.8 kg', label: 'Waste prevented'),
            ],
          ),
          const SizedBox(height: 24),
          Text('Monthly progress', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          const AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Food waste reduction goal'),
                SizedBox(height: 10),
                LinearProgressIndicator(value: 0.72, minHeight: 12),
                SizedBox(height: 8),
                Text('72% of your monthly target'),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text('Favorite ingredients', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              children: [
                if (sortedCategories.isEmpty) const Text('Add food to see ingredient trends.'),
                for (final entry in sortedCategories.take(5))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Text(entry.key.emoji, style: const TextStyle(fontSize: 26)),
                    title: Text(entry.key.label),
                    trailing: Text('${entry.value} item(s)'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('CSV export prepared in production mode.')),
            ),
            icon: const Icon(Icons.download_rounded),
            label: const Text('Export monthly report'),
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.icon, required this.value, required this.label});

  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const Spacer(),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          Text(label),
        ],
      ),
    );
  }
}
