import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/widgets/empty_state.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class ShoppingScreen extends ConsumerStatefulWidget {
  const ShoppingScreen({super.key});

  @override
  ConsumerState<ShoppingScreen> createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends ConsumerState<ShoppingScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _add() {
    final name = _controller.text.trim();
    if (name.isEmpty) return;
    ref.read(shoppingProvider.notifier).add(name);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(shoppingProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping list'),
        actions: [
          IconButton(
            tooltip: 'Generate from low stock',
            onPressed: () {
              final inventory = ref.read(inventoryProvider).asData?.value ?? const <FoodItem>[];
              ref.read(shoppingProvider.notifier).generateFromInventory(inventory);
            },
            icon: const Icon(Icons.auto_awesome_rounded),
          ),
          IconButton(
            tooltip: 'Remove checked',
            onPressed: ref.read(shoppingProvider.notifier).removeChecked,
            icon: const Icon(Icons.cleaning_services_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (_) => _add(),
                    decoration: const InputDecoration(
                      hintText: 'Add an item',
                      prefixIcon: Icon(Icons.add_shopping_cart_rounded),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton.filled(
                  onPressed: _add,
                  icon: const Icon(Icons.add_rounded),
                ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const EmptyState(
                    icon: Icons.shopping_bag_outlined,
                    title: 'Your list is empty',
                    message: 'Missing recipe ingredients and low-stock items appear here.',
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return Card(
                        child: CheckboxListTile(
                          value: item.checked,
                          onChanged: (_) => ref
                              .read(shoppingProvider.notifier)
                              .toggle(item.id),
                          title: Text(
                            item.name,
                            style: TextStyle(
                              decoration:
                                  item.checked ? TextDecoration.lineThrough : null,
                            ),
                          ),
                          subtitle: Text('${item.quantity} · ${item.reason}'),
                          secondary: const Icon(Icons.shopping_basket_outlined),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
