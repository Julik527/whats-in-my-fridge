import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';
import 'package:whats_in_my_fridge/presentation/screens/more/settings_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/more/shopping_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/more/statistics_screen.dart';

class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(authControllerProvider).asData?.value;
    final shoppingCount = ref.watch(shoppingProvider).where((item) => !item.checked).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  child: Text(
                    (session?.displayName?.isNotEmpty == true
                            ? session!.displayName![0]
                            : 'U')
                        .toUpperCase(),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        session?.displayName ?? 'User',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      Text(session?.email ?? 'No email'),
                    ],
                  ),
                ),
                if (session?.isDemo == true) const Chip(label: Text('Demo')),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        _MoreTile(
          icon: Icons.shopping_cart_outlined,
          title: 'Shopping list',
          subtitle: '$shoppingCount open item(s)',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const ShoppingScreen()),
          ),
        ),
        _MoreTile(
          icon: Icons.insights_outlined,
          title: 'Statistics',
          subtitle: 'Waste prevented, money saved and reports',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const StatisticsScreen()),
          ),
        ),
        _MoreTile(
          icon: Icons.settings_outlined,
          title: 'Settings',
          subtitle: 'Theme, units, notifications and preferences',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
          ),
        ),
        const SizedBox(height: 18),
        OutlinedButton.icon(
          onPressed: ref.read(authControllerProvider.notifier).signOut,
          icon: const Icon(Icons.logout_rounded),
          label: const Text('Sign out'),
        ),
      ],
    );
  }
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}
