import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:whats_in_my_fridge/core/utils/date_formatters.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

Future<void> showFoodFormSheet(BuildContext context, {FoodItem? item}) async {
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => FoodFormSheet(item: item),
  );
}

class FoodFormSheet extends ConsumerStatefulWidget {
  const FoodFormSheet({this.item, super.key});

  final FoodItem? item;

  @override
  ConsumerState<FoodFormSheet> createState() => _FoodFormSheetState();
}

class _FoodFormSheetState extends ConsumerState<FoodFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _quantity;
  late final TextEditingController _unit;
  late final TextEditingController _storage;
  late final TextEditingController _notes;
  late FoodCategory _category;
  late DateTime _purchaseDate;
  late DateTime _expirationDate;
  bool _saving = false;
  Uint8List? _imageBytes;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    _name = TextEditingController(text: item?.name ?? '');
    _quantity = TextEditingController(text: item?.quantity.toString() ?? '1');
    _unit = TextEditingController(text: item?.unit ?? 'pcs');
    _storage = TextEditingController(text: item?.storageLocation ?? 'Fridge');
    _notes = TextEditingController(text: item?.notes ?? '');
    _category = item?.category ?? FoodCategory.vegetables;
    _purchaseDate = item?.purchaseDate ?? DateTime.now();
    _expirationDate = item?.expirationDate ?? DateTime.now().add(const Duration(days: 7));
  }

  @override
  void dispose() {
    _name.dispose();
    _quantity.dispose();
    _unit.dispose();
    _storage.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool expiration}) async {
    final initial = expiration ? _expirationDate : _purchaseDate;
    final value = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime.now().subtract(const Duration(days: 3650)),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (value == null) return;
    setState(() {
      if (expiration) {
        _expirationDate = value;
      } else {
        _purchaseDate = value;
      }
    });
  }

  Future<void> _pickImage() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
      maxWidth: 1600,
    );
    if (image == null) return;
    final bytes = await image.readAsBytes();
    if (!mounted) return;
    setState(() => _imageBytes = bytes);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final now = DateTime.now();
    final id = widget.item?.id ?? now.microsecondsSinceEpoch.toString();
    var imageUrl = widget.item?.imageUrl;
    final session = ref.read(authControllerProvider).asData?.value;
    if (_imageBytes != null && session?.uid != null) {
      imageUrl = await ref.read(imageStorageServiceProvider).uploadFoodImage(
            uid: session!.uid!,
            itemId: id,
            bytes: _imageBytes!,
          ) ?? imageUrl;
    }
    final item = FoodItem(
      id: id,
      name: _name.text.trim(),
      category: _category,
      quantity: double.parse(_quantity.text.replaceAll(',', '.')),
      unit: _unit.text.trim(),
      purchaseDate: _purchaseDate,
      expirationDate: _expirationDate,
      storageLocation: _storage.text.trim(),
      imageUrl: imageUrl,
      notes: _notes.text.trim(),
      createdAt: widget.item?.createdAt ?? now,
    );
    await ref.read(inventoryProvider.notifier).save(item);
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.viewInsetsOf(context).bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                widget.item == null ? 'Add food' : 'Edit food',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _name,
                autofocus: widget.item == null,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  prefixIcon: Icon(Icons.restaurant_rounded),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Enter a food name.'
                    : null,
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<FoodCategory>(
                initialValue: _category,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
                items: [
                  for (final category in FoodCategory.values)
                    DropdownMenuItem(
                      value: category,
                      child: Text('${category.emoji}  ${category.label}'),
                    ),
                ],
                onChanged: (value) => setState(() => _category = value!),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _quantity,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'Quantity'),
                      validator: (value) => double.tryParse(
                                (value ?? '').replaceAll(',', '.'),
                              ) ==
                              null
                          ? 'Invalid number'
                          : null,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _unit,
                      decoration: const InputDecoration(labelText: 'Unit'),
                      validator: (value) => value == null || value.trim().isEmpty
                          ? 'Enter a unit.'
                          : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _storage,
                decoration: const InputDecoration(
                  labelText: 'Storage location',
                  prefixIcon: Icon(Icons.kitchen_outlined),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _DateButton(
                      label: 'Purchased',
                      value: shortDate(_purchaseDate),
                      onTap: () => _pickDate(expiration: false),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _DateButton(
                      label: 'Expires',
                      value: shortDate(_expirationDate),
                      onTap: () => _pickDate(expiration: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              InkWell(
                onTap: _pickImage,
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                  ),
                  child: _imageBytes == null
                      ? const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_photo_alternate_outlined),
                            SizedBox(height: 6),
                            Text('Add food image'),
                          ],
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(17),
                          child: Image.memory(_imageBytes!, fit: BoxFit.cover, width: double.infinity),
                        ),
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _notes,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Notes',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.check_rounded),
                label: Text(widget.item == null ? 'Add to inventory' : 'Save changes'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DateButton extends StatelessWidget {
  const _DateButton({
    required this.label,
    required this.value,
    required this.onTap,
  });

  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: const Icon(Icons.calendar_today_outlined),
        ),
        child: Text(value),
      ),
    );
  }
}
