import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:whats_in_my_fridge/core/widgets/empty_state.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class AiScanScreen extends ConsumerStatefulWidget {
  const AiScanScreen({super.key});

  @override
  ConsumerState<AiScanScreen> createState() => _AiScanScreenState();
}

class _AiScanScreenState extends ConsumerState<AiScanScreen> {
  final _picker = ImagePicker();

  Future<void> _takePhoto() async {
    final image = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
      maxWidth: 1600,
    );
    if (image == null) return;
    await ref.read(aiRecognitionProvider.notifier).analyze(await image.readAsBytes());
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _takePhoto());
  }

  @override
  Widget build(BuildContext context) {
    final recognition = ref.watch(aiRecognitionProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('AI fridge scan')),
      body: recognition.when(
        loading: () => const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Identifying foods…'),
            ],
          ),
        ),
        error: (error, stackTrace) => EmptyState(
          icon: Icons.error_outline_rounded,
          title: 'Could not analyze the image',
          message: error.toString(),
          action: FilledButton(onPressed: _takePhoto, child: const Text('Try again')),
        ),
        data: (foods) {
          if (foods.isEmpty) {
            return EmptyState(
              icon: Icons.camera_alt_outlined,
              title: 'Photograph your fridge',
              message: 'The AI will identify visible food and let you confirm every item.',
              action: FilledButton.icon(
                onPressed: _takePhoto,
                icon: const Icon(Icons.camera_alt_rounded),
                label: const Text('Take photo'),
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'Confirm detected food',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 8),
              const Text('Uncheck anything that was detected incorrectly.'),
              const SizedBox(height: 20),
              for (var index = 0; index < foods.length; index++)
                Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: CheckboxListTile(
                    value: foods[index].selected,
                    onChanged: (_) => ref.read(aiRecognitionProvider.notifier).toggle(index),
                    secondary: Text(
                      foods[index].category.emoji,
                      style: const TextStyle(fontSize: 30),
                    ),
                    title: Text(foods[index].name),
                    subtitle: Text(
                      '${foods[index].category.label} · ${(foods[index].confidence * 100).round()}% confidence',
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () async {
                  await ref.read(inventoryProvider.notifier).addDetected(foods);
                  ref.read(aiRecognitionProvider.notifier).clear();
                  if (!mounted) return;
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.add_rounded),
                label: Text('Add ${foods.where((food) => food.selected).length} items'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _takePhoto,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Take another photo'),
              ),
            ],
          );
        },
      ),
    );
  }
}
