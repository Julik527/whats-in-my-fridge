import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/utils/date_formatters.dart';
import 'package:whats_in_my_fridge/core/widgets/empty_state.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';
import 'package:whats_in_my_fridge/presentation/screens/inventory/ai_scan_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/inventory/barcode_scanner_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/inventory/food_form_sheet.dart';

class InventoryScreen extends ConsumerStatefulWidget {
  const InventoryScreen({super.key});

  @override
  ConsumerState<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends ConsumerState<InventoryScreen> {
  String _query = '';
  FoodCategory? _category;

  Future<void> _scanBarcode() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()),
    );
    if (code == null || !mounted) return;
    final now = DateTime.now();
    await ref.read(inventoryProvider.notifier).save(
          FoodItem(
            id: now.microsecondsSinceEpoch.toString(),
            name: 'Scanned product',
            category: FoodCategory.pantry,
            quantity: 1,
            unit: 'pcs',
            purchaseDate: now,
            expirationDate: now.add(const Duration(days: 30)),
            storageLocation: 'Pantry',
            notes: 'Barcode: $code. Review product data and expiration date.',
            createdAt: now,
          ),
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Barcode $code added. Please review the item.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inventory = ref.watch(inventoryProvider);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
          child: Column(
            children: [
              SearchBar(
                hintText: 'Search your inventory',
                leading: const Icon(Icons.search_rounded),
                onChanged: (value) => setState(() => _query = value.trim().toLowerCase()),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 42,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    FilterChip(
                      label: const Text('All'),
                      selected: _category == null,
                      onSelected: (_) => setState(() => _category = null),
                    ),
                    const SizedBox(width: 8),
                    for (final category in FoodCategory.values) ...[
                      FilterChip(
                        avatar: Text(category.emoji),
                        label: Text(category.label),
                        selected: _category == category,
                        onSelected: (_) => setState(() => _category = category),
                      ),
                      const SizedBox(width: 8),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _scanBarcode,
                      icon: const Icon(Icons.qr_code_scanner_rounded),
                      label: const Text('Barcode'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => const AiScanScreen()),
                      ),
                      icon: const Icon(Icons.camera_alt_outlined),
                      label: const Text('AI photo'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: inventory.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stackTrace) => Center(child: Text(error.toString())),
            data: (items) {
              final filtered = items.where((item) {
                final matchesQuery = _query.isEmpty ||
                    item.name.toLowerCase().contains(_query) ||
                    item.notes.toLowerCase().contains(_query);
                return matchesQuery && (_category == null || item.category == _category);
              }).toList()
                ..sort((a, b) => a.expirationDate.compareTo(b.expirationDate));

              if (filtered.isEmpty) {
                return EmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'No matching food',
                  message: 'Add an item manually, scan a barcode, or photograph your fridge.',
                  action: FilledButton.icon(
                    onPressed: () => showFoodFormSheet(context),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Add food'),
                  ),
                );
              }

              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 120),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) => _FoodTile(item: filtered[index]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _FoodTile extends ConsumerWidget {
  const _FoodTile({required this.item});

  final FoodItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final days = item.daysUntilExpiration;
    final urgent = days <= 1;
    final label = switch (days) {
      < 0 => 'Expired ${days.abs()}d ago',
      0 => 'Expires today',
      1 => 'Expires tomorrow',
      _ => 'Expires in $days days',
    };

    return Dismissible(
      key: ValueKey(item.id),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async => await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Delete food?'),
              content: Text('Remove ${item.name} from your inventory?'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
              ],
            ),
          ) ??
          false,
      onDismissed: (_) => ref.read(inventoryProvider.notifier).delete(item.id),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        decoration: BoxDecoration(
          color: scheme.errorContainer,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Icon(Icons.delete_outline_rounded, color: scheme.onErrorContainer),
      ),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => showFoodFormSheet(context, item: item),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: urgent ? scheme.errorContainer : scheme.primaryContainer,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Text(item.category.emoji, style: const TextStyle(fontSize: 28)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      const SizedBox(height: 3),
                      Text('${item.quantity} ${item.unit} · ${item.storageLocation}'),
                      const SizedBox(height: 3),
                      Text(
                        '$label · ${shortDate(item.expirationDate)}',
                        style: TextStyle(
                          color: urgent ? scheme.error : scheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
