import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/widgets/empty_state.dart';
import 'package:whats_in_my_fridge/domain/entities/recipe.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class RecipesScreen extends ConsumerWidget {
  const RecipesScreen({super.key});

  static const filters = [
    'Vegetarian',
    'Vegan',
    'Gluten-free',
    'High protein',
    'Low carb',
    'Under 30 minutes',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(recipeFiltersProvider);
    final recipes = ref.watch(recipesProvider);

    return Column(
      children: [
        SizedBox(
          height: 54,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            scrollDirection: Axis.horizontal,
            itemCount: filters.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final filter = filters[index];
              return FilterChip(
                label: Text(filter),
                selected: selected.contains(filter),
                onSelected: (_) {
                  ref.read(recipeFiltersProvider.notifier).toggle(filter);
                  ref.invalidate(recipesProvider);
                },
              );
            },
          ),
        ),
        Expanded(
          child: recipes.when(
            loading: () => const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 14),
                  Text('Creating recipes from your inventory…'),
                ],
              ),
            ),
            error: (error, stackTrace) => EmptyState(
              icon: Icons.error_outline_rounded,
              title: 'Recipe generation failed',
              message: error.toString(),
              action: FilledButton(
                onPressed: () => ref.invalidate(recipesProvider),
                child: const Text('Try again'),
              ),
            ),
            data: (items) {
              if (items.isEmpty) {
                return const EmptyState(
                  icon: Icons.restaurant_menu_rounded,
                  title: 'No recipes match every filter',
                  message: 'Remove one or two filters or add more ingredients to your inventory.',
                );
              }
              return RefreshIndicator(
                onRefresh: () async => ref.invalidate(recipesProvider),
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 120),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 14),
                  itemBuilder: (context, index) => _RecipeCard(recipe: items[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _RecipeCard extends ConsumerWidget {
  const _RecipeCard({required this.recipe});

  final Recipe recipe;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => showModalBottomSheet<void>(
          context: context,
          isScrollControlled: true,
          useSafeArea: true,
          builder: (_) => _RecipeDetails(recipe: recipe),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 126,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    scheme.primaryContainer,
                    scheme.tertiaryContainer,
                  ],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          recipe.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                        ),
                        const Spacer(),
                        Row(
                          children: [
                            const Icon(Icons.schedule_rounded, size: 18),
                            const SizedBox(width: 5),
                            Text('${recipe.minutes} min'),
                            const SizedBox(width: 16),
                            const Icon(Icons.fitness_center_rounded, size: 18),
                            const SizedBox(width: 5),
                            Text('${recipe.proteinGrams} g protein'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => ref
                        .read(recipesProvider.notifier)
                        .toggleFavorite(recipe.id),
                    icon: Icon(
                      recipe.isFavorite
                          ? Icons.favorite_rounded
                          : Icons.favorite_border_rounded,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(recipe.description),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      for (final tag in recipe.tags.take(4))
                        Chip(
                          visualDensity: VisualDensity.compact,
                          label: Text(tag),
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(
                        recipe.missingIngredients.isEmpty
                            ? Icons.check_circle_outline_rounded
                            : Icons.shopping_cart_outlined,
                        size: 18,
                        color: recipe.missingIngredients.isEmpty
                            ? scheme.primary
                            : scheme.tertiary,
                      ),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          recipe.missingIngredients.isEmpty
                              ? 'You have every ingredient'
                              : '${recipe.missingIngredients.length} missing ingredient(s)',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                      const Icon(Icons.chevron_right_rounded),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecipeDetails extends ConsumerWidget {
  const _RecipeDetails({required this.recipe});

  final Recipe recipe;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 0, 22, 28),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              recipe.title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 8),
            Text(recipe.description),
            const SizedBox(height: 22),
            Text('Ingredients', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final ingredient in recipe.ingredients)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.check_circle_outline_rounded),
                title: Text(ingredient),
              ),
            if (recipe.missingIngredients.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text('Missing', style: Theme.of(context).textTheme.titleMedium),
              for (final ingredient in recipe.missingIngredients)
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.add_shopping_cart_rounded),
                  title: Text(ingredient),
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () {
                  ref.read(shoppingProvider.notifier).addMissingIngredients(recipe);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Missing ingredients added to shopping list.')),
                  );
                },
                icon: const Icon(Icons.playlist_add_rounded),
                label: const Text('Add missing items to shopping list'),
              ),
            ],
            const SizedBox(height: 24),
            Text('Instructions', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            for (var index = 0; index < recipe.instructions.length; index++)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 14,
                      child: Text('${index + 1}'),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Text(recipe.instructions[index])),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
