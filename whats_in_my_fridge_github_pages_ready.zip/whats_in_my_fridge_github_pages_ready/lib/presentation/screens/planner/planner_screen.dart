import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/utils/date_formatters.dart';
import 'package:whats_in_my_fridge/domain/entities/meal_plan_entry.dart';
import 'package:whats_in_my_fridge/domain/entities/recipe.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';

class PlannerScreen extends ConsumerWidget {
  const PlannerScreen({super.key});

  List<DateTime> _week() {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    return List.generate(
      7,
      (index) => DateTime(monday.year, monday.month, monday.day + index),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final recipes = ref.watch(recipesProvider);
    final plan = ref.watch(mealPlanProvider);
    final week = _week();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
      children: [
        Text(
          'Drag a recipe onto a day',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w700,
              ),
        ),
        const SizedBox(height: 12),
        recipes.when(
          loading: () => const SizedBox(
            height: 106,
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (error, stackTrace) => Text('Recipes unavailable: $error'),
          data: (items) => SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) => _DraggableRecipe(recipe: items[index]),
            ),
          ),
        ),
        const SizedBox(height: 26),
        Row(
          children: [
            Expanded(
              child: Text(
                'This week',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ),
            const Chip(
              avatar: Icon(Icons.auto_awesome_rounded, size: 18),
              label: Text('Expiry optimized'),
            ),
          ],
        ),
        const SizedBox(height: 14),
        for (final date in week) ...[
          _DayTarget(
            date: date,
            entries: plan.where((entry) => DateUtils.isSameDay(entry.date, date)).toList(),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _DraggableRecipe extends StatelessWidget {
  const _DraggableRecipe({required this.recipe});

  final Recipe recipe;

  @override
  Widget build(BuildContext context) {
    final card = Container(
      width: 174,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.drag_indicator_rounded),
          const Spacer(),
          Text(
            recipe.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          Text('${recipe.minutes} min'),
        ],
      ),
    );

    return LongPressDraggable<Recipe>(
      data: recipe,
      feedback: Material(
        color: Colors.transparent,
        child: Transform.scale(scale: 1.03, child: card),
      ),
      childWhenDragging: Opacity(opacity: 0.35, child: card),
      child: card,
    );
  }
}

class _DayTarget extends ConsumerWidget {
  const _DayTarget({required this.date, required this.entries});

  final DateTime date;
  final List<MealPlanEntry> entries;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final today = DateUtils.isSameDay(date, DateTime.now());
    return DragTarget<Recipe>(
      onAcceptWithDetails: (details) =>
          ref.read(mealPlanProvider.notifier).add(date, details.data),
      builder: (context, candidates, rejected) {
        final active = candidates.isNotEmpty;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          constraints: const BoxConstraints(minHeight: 94),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: active
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surfaceContainerLow,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: today
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.outlineVariant,
              width: today ? 1.8 : 1,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 54,
                child: Column(
                  children: [
                    Text(
                      weekday(date),
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: today ? Theme.of(context).colorScheme.primary : null,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${date.day}',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: entries.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 18),
                        child: Text(
                          active ? 'Release to plan this recipe' : 'Drop dinner here',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      )
                    : Column(
                        children: [
                          for (final entry in entries)
                            ListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              leading: const CircleAvatar(
                                child: Icon(Icons.restaurant_rounded, size: 18),
                              ),
                              title: Text(entry.recipe.title),
                              subtitle: Text('${entry.mealType} · ${entry.recipe.minutes} min'),
                              trailing: IconButton(
                                onPressed: () => ref
                                    .read(mealPlanProvider.notifier)
                                    .remove(entry.id),
                                icon: const Icon(Icons.close_rounded),
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
