import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:whats_in_my_fridge/data/services/firebase_bootstrap.dart';

class ImageStorageService {
  Future<String?> uploadFoodImage({
    required String uid,
    required String itemId,
    required Uint8List bytes,
  }) async {
    if (!FirebaseBootstrap.isReady || uid == 'demo-user') return null;
    final ref = FirebaseStorage.instance.ref('users/$uid/foods/$itemId.jpg');
    await ref.putData(
      bytes,
      SettableMetadata(contentType: 'image/jpeg', cacheControl: 'public,max-age=3600'),
    );
    return ref.getDownloadURL();
  }
}
