import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:whats_in_my_fridge/data/services/firebase_bootstrap.dart';
import 'package:whats_in_my_fridge/domain/entities/detected_food.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/domain/entities/recipe.dart';

class AiService {
  Future<List<DetectedFood>> recognizeFoods(Uint8List imageBytes) async {
    if (FirebaseBootstrap.isReady) {
      try {
        final callable = FirebaseFunctions.instanceFor(region: 'europe-west1').httpsCallable('recognizeFridge');
        final response = await callable.call<Map<String, dynamic>>({
          'imageBase64': base64Encode(imageBytes),
        });
        final foods = response.data['foods'] as List<dynamic>? ?? const [];
        return foods.map((raw) {
          final map = Map<String, dynamic>.from(raw as Map);
          return DetectedFood(
            name: map['name'] as String,
            category: FoodCategory.values.firstWhere(
              (value) => value.name == map['category'],
              orElse: () => FoodCategory.pantry,
            ),
            confidence: (map['confidence'] as num?)?.toDouble() ?? 0.8,
          );
        }).toList();
      } on Object {
        // Fall through to deterministic demo results.
      }
    }

    return const [
      DetectedFood(
        name: 'Bell Pepper',
        category: FoodCategory.vegetables,
        confidence: 0.94,
      ),
      DetectedFood(
        name: 'Greek Yogurt',
        category: FoodCategory.dairy,
        confidence: 0.89,
      ),
      DetectedFood(
        name: 'Eggs',
        category: FoodCategory.dairy,
        confidence: 0.86,
      ),
    ];
  }

  Future<List<Recipe>> generateRecipes({
    required List<FoodItem> inventory,
    required Set<String> filters,
  }) async {
    if (FirebaseBootstrap.isReady) {
      try {
        final callable = FirebaseFunctions.instanceFor(region: 'europe-west1').httpsCallable('generateRecipes');
        final response = await callable.call<Map<String, dynamic>>({
          'inventory': inventory.map((item) => item.toMap()).toList(),
          'filters': filters.toList(),
        });
        final recipes = response.data['recipes'] as List<dynamic>? ?? const [];
        return recipes
            .map((raw) => Recipe.fromMap(Map<String, Object?>.from(raw as Map)))
            .toList();
      } on Object {
        // Fall through to local recipes.
      }
    }
    return _localRecipes(inventory, filters);
  }

  Future<String> answerAssistant({
    required String prompt,
    required List<FoodItem> inventory,
  }) async {
    if (FirebaseBootstrap.isReady) {
      try {
        final callable = FirebaseFunctions.instanceFor(region: 'europe-west1').httpsCallable('askFridgeAssistant');
        final response = await callable.call<Map<String, dynamic>>({
          'prompt': prompt,
          'inventory': inventory.map((item) => item.toMap()).toList(),
        });
        return response.data['answer'] as String;
      } on Object {
        // Fall through to local assistant.
      }
    }

    final lower = prompt.toLowerCase();
    final soon = [...inventory]..sort(
        (a, b) => a.expirationDate.compareTo(b.expirationDate),
      );
    if (lower.contains('expire') || lower.contains('tomorrow')) {
      final names = soon
          .where((item) => item.daysUntilExpiration <= 1)
          .map((item) => '${item.name} (${item.daysUntilExpiration == 0 ? 'today' : 'tomorrow'})')
          .join(', ');
      return names.isEmpty
          ? 'Nothing expires today or tomorrow.'
          : 'Use these first: $names.';
    }
    if (lower.contains('shopping')) {
      return 'I would add onions, garlic, whole-grain wraps, and a protein source. They combine well with your current ingredients.';
    }
    if (lower.contains('protein')) {
      return 'Try a high-protein chicken and spinach rice bowl. It uses the chicken and spinach before they expire and takes about 25 minutes.';
    }
    return 'Tonight I would cook the ingredients that expire first: ${soon.take(3).map((item) => item.name).join(', ')}. A quick skillet or rice bowl would work well.';
  }

  List<Recipe> _localRecipes(List<FoodItem> inventory, Set<String> filters) {
    final names = inventory.map((item) => item.name.toLowerCase()).toSet();
    final recipes = <Recipe>[
      Recipe(
        id: 'chicken-bowl',
        title: 'Chicken Spinach Rice Bowl',
        description: 'A fast, balanced bowl that uses your most urgent ingredients first.',
        minutes: 25,
        ingredients: const ['Chicken Breast', 'Baby Spinach', 'Basmati Rice', 'Cherry Tomatoes'],
        missingIngredients: [if (!names.any((n) => n.contains('garlic'))) 'Garlic'],
        instructions: const [
          'Cook the rice.',
          'Season and sear the chicken.',
          'Wilt spinach and tomatoes in the same pan.',
          'Serve everything in a bowl.',
        ],
        tags: const {'High protein', 'Under 30 minutes', 'Gluten-free'},
        proteinGrams: 46,
      ),
      const Recipe(
        id: 'spinach-omelette',
        title: 'Spinach Tomato Omelette',
        description: 'Simple, high-protein and ideal for vegetables that need using now.',
        minutes: 15,
        ingredients: ['Eggs', 'Baby Spinach', 'Cherry Tomatoes'],
        missingIngredients: ['Eggs'],
        instructions: [
          'Whisk the eggs.',
          'Sauté spinach and tomatoes.',
          'Add eggs and fold when set.',
        ],
        tags: {'Vegetarian', 'High protein', 'Low carb', 'Under 30 minutes', 'Gluten-free'},
        proteinGrams: 28,
      ),
      const Recipe(
        id: 'berry-smoothie',
        title: 'Berry Oat Smoothie',
        description: 'A creamy breakfast or snack with frozen berries and oat milk.',
        minutes: 5,
        ingredients: ['Frozen Berries', 'Oat Milk', 'Oats'],
        missingIngredients: ['Oats'],
        instructions: ['Blend all ingredients until smooth.'],
        tags: {'Vegan', 'Vegetarian', 'Under 30 minutes'},
        proteinGrams: 12,
      ),
    ];

    if (filters.isEmpty) return recipes;
    return recipes.where((recipe) => filters.every(recipe.tags.contains)).toList();
  }
}
