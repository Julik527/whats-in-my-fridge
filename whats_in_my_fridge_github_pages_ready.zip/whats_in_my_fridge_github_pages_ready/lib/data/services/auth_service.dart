import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:whats_in_my_fridge/data/services/firebase_bootstrap.dart';

class AppAuthState {
  const AppAuthState({
    required this.isAuthenticated,
    this.uid,
    this.email,
    this.displayName,
    this.isDemo = false,
  });

  const AppAuthState.signedOut()
      : isAuthenticated = false,
        uid = null,
        email = null,
        displayName = null,
        isDemo = false;

  final bool isAuthenticated;
  final String? uid;
  final String? email;
  final String? displayName;
  final bool isDemo;
}

class AuthService {
  FirebaseAuth? get _auth => FirebaseBootstrap.isReady ? FirebaseAuth.instance : null;

  AppAuthState currentState() {
    final user = _auth?.currentUser;
    if (user == null) return const AppAuthState.signedOut();
    return AppAuthState(
      isAuthenticated: true,
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
    );
  }

  Future<AppAuthState> signIn(String email, String password) async {
    final auth = _auth;
    if (auth == null) return _demo(email);
    final result = await auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    return _fromUser(result.user);
  }

  Future<AppAuthState> signUp(String email, String password, String name) async {
    final auth = _auth;
    if (auth == null) return _demo(email, name: name);
    final result = await auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    await result.user?.updateDisplayName(name.trim());
    return _fromUser(result.user, fallbackName: name);
  }

  Future<void> resetPassword(String email) async {
    final auth = _auth;
    if (auth == null) return;
    await auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<AppAuthState> signInWithGoogle() async {
    final auth = _auth;
    if (auth == null) return _demo('demo@fridge.app', name: 'Demo User');

    if (kIsWeb) {
      final result = await auth.signInWithPopup(GoogleAuthProvider());
      return _fromUser(result.user);
    }

    await GoogleSignIn.instance.initialize();
    final account = await GoogleSignIn.instance.authenticate();
    final authentication = account.authentication;
    final credential = GoogleAuthProvider.credential(
      idToken: authentication.idToken,
    );
    final result = await auth.signInWithCredential(credential);
    return _fromUser(result.user);
  }

  Future<AppAuthState> signInWithApple() async {
    final auth = _auth;
    if (auth == null) return _demo('apple-demo@fridge.app', name: 'Apple User');
    final provider = AppleAuthProvider();
    final result = kIsWeb
        ? await auth.signInWithPopup(provider)
        : await auth.signInWithProvider(provider);
    return _fromUser(result.user);
  }

  Future<void> signOut() async {
    if (_auth != null) await _auth!.signOut();
  }

  AppAuthState _fromUser(User? user, {String? fallbackName}) {
    if (user == null) return const AppAuthState.signedOut();
    return AppAuthState(
      isAuthenticated: true,
      uid: user.uid,
      email: user.email,
      displayName: user.displayName ?? fallbackName,
    );
  }

  AppAuthState _demo(String email, {String? name}) => AppAuthState(
        isAuthenticated: true,
        uid: 'demo-user',
        email: email,
        displayName: name ?? 'Demo User',
        isDemo: true,
      );
}
