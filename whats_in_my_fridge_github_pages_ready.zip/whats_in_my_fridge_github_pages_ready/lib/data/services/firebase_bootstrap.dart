import 'package:firebase_core/firebase_core.dart';

class FirebaseBootstrap {
  static bool _ready = false;

  static bool get isReady => _ready && Firebase.apps.isNotEmpty;

  static Future<void> initialize() async {
    try {
      await Firebase.initializeApp();
      _ready = true;
    } on Object {
      // The app remains usable in demo mode until FlutterFire is configured.
      _ready = false;
    }
  }
}
