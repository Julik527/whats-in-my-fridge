import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:whats_in_my_fridge/data/services/firebase_bootstrap.dart';

class NotificationService {
  Future<void> registerForUser(String uid) async {
    if (!FirebaseBootstrap.isReady || uid == 'demo-user') return;
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(alert: true, badge: true, sound: true);
    final token = await messaging.getToken();
    if (token == null) return;
    await FirebaseFirestore.instance.collection('users').doc(uid).set(
      {
        'fcmTokens': FieldValue.arrayUnion([token]),
        'notificationPreferences': {
          'today': true,
          'tomorrow': true,
          'threeDays': true,
        },
      },
      SetOptions(merge: true),
    );
  }
}
