import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/domain/repositories/inventory_repository.dart';

class DemoInventoryRepository implements InventoryRepository {
  DemoInventoryRepository() : _items = _seedItems();

  final List<FoodItem> _items;

  @override
  Future<List<FoodItem>> getItems() async => List.unmodifiable(_items);

  @override
  Future<void> saveItem(FoodItem item) async {
    final index = _items.indexWhere((value) => value.id == item.id);
    if (index == -1) {
      _items.insert(0, item);
    } else {
      _items[index] = item;
    }
  }

  @override
  Future<void> deleteItem(String id) async {
    _items.removeWhere((item) => item.id == id);
  }

  static List<FoodItem> _seedItems() {
    final now = DateTime.now();
    DateTime plus(int days) => DateTime(now.year, now.month, now.day + days);

    return [
      FoodItem(
        id: 'milk',
        name: 'Oat Milk',
        category: FoodCategory.dairy,
        quantity: 1,
        unit: 'carton',
        purchaseDate: plus(-3),
        expirationDate: plus(0),
        storageLocation: 'Fridge',
        notes: 'Opened yesterday',
        createdAt: now.subtract(const Duration(hours: 3)),
      ),
      FoodItem(
        id: 'spinach',
        name: 'Baby Spinach',
        category: FoodCategory.vegetables,
        quantity: 180,
        unit: 'g',
        purchaseDate: plus(-2),
        expirationDate: plus(1),
        storageLocation: 'Fridge',
        createdAt: now.subtract(const Duration(hours: 5)),
      ),
      FoodItem(
        id: 'chicken',
        name: 'Chicken Breast',
        category: FoodCategory.meat,
        quantity: 450,
        unit: 'g',
        purchaseDate: plus(-1),
        expirationDate: plus(2),
        storageLocation: 'Fridge',
        createdAt: now.subtract(const Duration(days: 1)),
      ),
      FoodItem(
        id: 'tomatoes',
        name: 'Cherry Tomatoes',
        category: FoodCategory.vegetables,
        quantity: 250,
        unit: 'g',
        purchaseDate: plus(-2),
        expirationDate: plus(4),
        storageLocation: 'Fridge',
        createdAt: now.subtract(const Duration(days: 2)),
      ),
      FoodItem(
        id: 'rice',
        name: 'Basmati Rice',
        category: FoodCategory.pantry,
        quantity: 1,
        unit: 'kg',
        purchaseDate: plus(-20),
        expirationDate: plus(200),
        storageLocation: 'Pantry',
        createdAt: now.subtract(const Duration(days: 20)),
      ),
      FoodItem(
        id: 'berries',
        name: 'Frozen Berries',
        category: FoodCategory.frozen,
        quantity: 500,
        unit: 'g',
        purchaseDate: plus(-5),
        expirationDate: plus(100),
        storageLocation: 'Freezer',
        createdAt: now.subtract(const Duration(days: 5)),
      ),
    ];
  }
}
