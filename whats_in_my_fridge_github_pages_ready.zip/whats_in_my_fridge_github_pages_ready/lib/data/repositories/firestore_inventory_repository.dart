import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';
import 'package:whats_in_my_fridge/domain/repositories/inventory_repository.dart';

class FirestoreInventoryRepository implements InventoryRepository {
  FirestoreInventoryRepository({
    required FirebaseFirestore firestore,
    required String uid,
  })  : _firestore = firestore,
        _uid = uid;

  final FirebaseFirestore _firestore;
  final String _uid;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection('users').doc(_uid).collection('inventory');

  @override
  Future<List<FoodItem>> getItems() async {
    final snapshot = await _collection.orderBy('expirationDate').get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return FoodItem.fromMap({
        ...data,
        'id': doc.id,
        'purchaseDate': (data['purchaseDate'] as Timestamp).toDate().toIso8601String(),
        'expirationDate': (data['expirationDate'] as Timestamp).toDate().toIso8601String(),
        'createdAt': (data['createdAt'] as Timestamp).toDate().toIso8601String(),
      });
    }).toList();
  }

  @override
  Future<void> saveItem(FoodItem item) async {
    final data = item.toMap();
    await _collection.doc(item.id).set({
      ...data,
      'purchaseDate': Timestamp.fromDate(item.purchaseDate),
      'expirationDate': Timestamp.fromDate(item.expirationDate),
      'createdAt': Timestamp.fromDate(item.createdAt),
    });
  }

  @override
  Future<void> deleteItem(String id) => _collection.doc(id).delete();
}
