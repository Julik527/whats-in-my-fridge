import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:whats_in_my_fridge/core/theme/app_theme.dart';
import 'package:whats_in_my_fridge/presentation/providers/app_providers.dart';
import 'package:whats_in_my_fridge/presentation/screens/auth/auth_screen.dart';
import 'package:whats_in_my_fridge/presentation/screens/home/home_shell.dart';

class FridgeApp extends ConsumerWidget {
  const FridgeApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "What's in My Fridge?",
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      home: const AuthGate(),
    );
  }
}

class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authControllerProvider);
    return auth.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (error, stackTrace) => AuthScreen(initialError: error.toString()),
      data: (session) => session.isAuthenticated
          ? const HomeShell()
          : const AuthScreen(),
    );
  }
}
