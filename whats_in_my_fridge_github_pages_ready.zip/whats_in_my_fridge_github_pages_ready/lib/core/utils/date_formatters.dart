import 'package:intl/intl.dart';

String shortDate(DateTime date) => DateFormat.MMMd().format(date);
String weekday(DateTime date) => DateFormat.E().format(date);
String fullDate(DateTime date) => DateFormat.yMMMd().format(date);
