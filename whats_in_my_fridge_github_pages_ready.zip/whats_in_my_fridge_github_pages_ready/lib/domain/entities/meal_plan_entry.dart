import 'package:whats_in_my_fridge/domain/entities/recipe.dart';

class MealPlanEntry {
  const MealPlanEntry({
    required this.id,
    required this.date,
    required this.mealType,
    required this.recipe,
  });

  final String id;
  final DateTime date;
  final String mealType;
  final Recipe recipe;
}
