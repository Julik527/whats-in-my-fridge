class ShoppingItem {
  const ShoppingItem({
    required this.id,
    required this.name,
    this.quantity = '1',
    this.checked = false,
    this.reason = 'Manual',
  });

  final String id;
  final String name;
  final String quantity;
  final bool checked;
  final String reason;

  ShoppingItem copyWith({bool? checked}) => ShoppingItem(
        id: id,
        name: name,
        quantity: quantity,
        checked: checked ?? this.checked,
        reason: reason,
      );
}
