class Recipe {
  const Recipe({
    required this.id,
    required this.title,
    required this.description,
    required this.minutes,
    required this.ingredients,
    required this.missingIngredients,
    required this.instructions,
    required this.tags,
    required this.proteinGrams,
    this.isFavorite = false,
  });

  final String id;
  final String title;
  final String description;
  final int minutes;
  final List<String> ingredients;
  final List<String> missingIngredients;
  final List<String> instructions;
  final Set<String> tags;
  final int proteinGrams;
  final bool isFavorite;

  Recipe copyWith({bool? isFavorite}) => Recipe(
        id: id,
        title: title,
        description: description,
        minutes: minutes,
        ingredients: ingredients,
        missingIngredients: missingIngredients,
        instructions: instructions,
        tags: tags,
        proteinGrams: proteinGrams,
        isFavorite: isFavorite ?? this.isFavorite,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'minutes': minutes,
        'ingredients': ingredients,
        'missingIngredients': missingIngredients,
        'instructions': instructions,
        'tags': tags.toList(),
        'proteinGrams': proteinGrams,
      };

  factory Recipe.fromMap(Map<String, Object?> map) => Recipe(
        id: (map['id'] as String?) ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: map['title']! as String,
        description: (map['description'] as String?) ?? '',
        minutes: (map['minutes'] as num?)?.toInt() ?? 30,
        ingredients: List<String>.from(map['ingredients'] as List? ?? const []),
        missingIngredients: List<String>.from(
          map['missingIngredients'] as List? ?? const [],
        ),
        instructions: List<String>.from(map['instructions'] as List? ?? const []),
        tags: Set<String>.from(map['tags'] as List? ?? const []),
        proteinGrams: (map['proteinGrams'] as num?)?.toInt() ?? 0,
      );
}
