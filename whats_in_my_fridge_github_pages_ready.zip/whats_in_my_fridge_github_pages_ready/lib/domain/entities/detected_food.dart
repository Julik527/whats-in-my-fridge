import 'package:whats_in_my_fridge/domain/entities/food_item.dart';

class DetectedFood {
  const DetectedFood({
    required this.name,
    required this.category,
    required this.confidence,
    this.selected = true,
  });

  final String name;
  final FoodCategory category;
  final double confidence;
  final bool selected;

  DetectedFood copyWith({bool? selected}) => DetectedFood(
        name: name,
        category: category,
        confidence: confidence,
        selected: selected ?? this.selected,
      );
}
