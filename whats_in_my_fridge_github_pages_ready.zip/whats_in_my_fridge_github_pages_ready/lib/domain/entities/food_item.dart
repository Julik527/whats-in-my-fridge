enum FoodCategory {
  dairy,
  meat,
  vegetables,
  fruits,
  drinks,
  frozen,
  pantry,
  snacks,
  condiments,
}

extension FoodCategoryX on FoodCategory {
  String get label => switch (this) {
        FoodCategory.dairy => 'Dairy',
        FoodCategory.meat => 'Meat',
        FoodCategory.vegetables => 'Vegetables',
        FoodCategory.fruits => 'Fruits',
        FoodCategory.drinks => 'Drinks',
        FoodCategory.frozen => 'Frozen',
        FoodCategory.pantry => 'Pantry',
        FoodCategory.snacks => 'Snacks',
        FoodCategory.condiments => 'Condiments',
      };

  String get emoji => switch (this) {
        FoodCategory.dairy => '🥛',
        FoodCategory.meat => '🥩',
        FoodCategory.vegetables => '🥦',
        FoodCategory.fruits => '🍎',
        FoodCategory.drinks => '🥤',
        FoodCategory.frozen => '❄️',
        FoodCategory.pantry => '🥫',
        FoodCategory.snacks => '🍿',
        FoodCategory.condiments => '🫙',
      };
}

class FoodItem {
  const FoodItem({
    required this.id,
    required this.name,
    required this.category,
    required this.quantity,
    required this.unit,
    required this.purchaseDate,
    required this.expirationDate,
    required this.storageLocation,
    this.imageUrl,
    this.notes = '',
    required this.createdAt,
  });

  final String id;
  final String name;
  final FoodCategory category;
  final double quantity;
  final String unit;
  final DateTime purchaseDate;
  final DateTime expirationDate;
  final String storageLocation;
  final String? imageUrl;
  final String notes;
  final DateTime createdAt;

  int get daysUntilExpiration {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final expiry = DateTime(
      expirationDate.year,
      expirationDate.month,
      expirationDate.day,
    );
    return expiry.difference(start).inDays;
  }

  bool get isExpired => daysUntilExpiration < 0;
  bool get expiresToday => daysUntilExpiration == 0;
  bool get expiresThisWeek => daysUntilExpiration >= 0 && daysUntilExpiration <= 7;

  FoodItem copyWith({
    String? id,
    String? name,
    FoodCategory? category,
    double? quantity,
    String? unit,
    DateTime? purchaseDate,
    DateTime? expirationDate,
    String? storageLocation,
    String? imageUrl,
    String? notes,
    DateTime? createdAt,
  }) {
    return FoodItem(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      purchaseDate: purchaseDate ?? this.purchaseDate,
      expirationDate: expirationDate ?? this.expirationDate,
      storageLocation: storageLocation ?? this.storageLocation,
      imageUrl: imageUrl ?? this.imageUrl,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'category': category.name,
        'quantity': quantity,
        'unit': unit,
        'purchaseDate': purchaseDate.toIso8601String(),
        'expirationDate': expirationDate.toIso8601String(),
        'storageLocation': storageLocation,
        'imageUrl': imageUrl,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory FoodItem.fromMap(Map<String, Object?> map) {
    return FoodItem(
      id: map['id']! as String,
      name: map['name']! as String,
      category: FoodCategory.values.firstWhere(
        (value) => value.name == map['category'],
        orElse: () => FoodCategory.pantry,
      ),
      quantity: (map['quantity']! as num).toDouble(),
      unit: (map['unit'] as String?) ?? 'pcs',
      purchaseDate: DateTime.parse(map['purchaseDate']! as String),
      expirationDate: DateTime.parse(map['expirationDate']! as String),
      storageLocation: (map['storageLocation'] as String?) ?? 'Fridge',
      imageUrl: map['imageUrl'] as String?,
      notes: (map['notes'] as String?) ?? '',
      createdAt: DateTime.parse(map['createdAt']! as String),
    );
  }
}
