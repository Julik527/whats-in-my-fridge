import 'package:whats_in_my_fridge/domain/entities/food_item.dart';

abstract interface class InventoryRepository {
  Future<List<FoodItem>> getItems();
  Future<void> saveItem(FoodItem item);
  Future<void> deleteItem(String id);
}
