import 'package:flutter_test/flutter_test.dart';
import 'package:whats_in_my_fridge/domain/entities/food_item.dart';

void main() {
  test('food item serialization round trip keeps core fields', () {
    final item = FoodItem(
      id: '1',
      name: 'Milk',
      category: FoodCategory.dairy,
      quantity: 1,
      unit: 'carton',
      purchaseDate: DateTime(2026, 7, 10),
      expirationDate: DateTime(2026, 7, 17),
      storageLocation: 'Fridge',
      notes: 'Opened',
      createdAt: DateTime(2026, 7, 10, 9),
    );

    final restored = FoodItem.fromMap(item.toMap());

    expect(restored.id, item.id);
    expect(restored.name, item.name);
    expect(restored.category, FoodCategory.dairy);
    expect(restored.expirationDate, item.expirationDate);
  });
}
