import {initializeApp} from "firebase-admin/app";
import {getFirestore, Timestamp} from "firebase-admin/firestore";
import {getMessaging} from "firebase-admin/messaging";
import {defineSecret} from "firebase-functions/params";
import {HttpsError, onCall} from "firebase-functions/v2/https";
import {onSchedule} from "firebase-functions/v2/scheduler";

initializeApp();

const geminiApiKey = defineSecret("GEMINI_API_KEY");
const region = "europe-west1";
const model = "gemini-2.5-flash";

type GeminiPart = {text?: string; inlineData?: {mimeType: string; data: string}};

function requireUser(auth: unknown): void {
  if (!auth) throw new HttpsError("unauthenticated", "Sign in is required.");
}

async function callGemini(parts: GeminiPart[], json = false): Promise<string> {
  const key = geminiApiKey.value();
  if (!key) throw new HttpsError("failed-precondition", "GEMINI_API_KEY is not configured.");

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({
        contents: [{role: "user", parts}],
        generationConfig: {
          temperature: json ? 0.2 : 0.5,
          responseMimeType: json ? "application/json" : "text/plain",
        },
      }),
    },
  );

  if (!response.ok) {
    const detail = await response.text();
    throw new HttpsError("internal", `AI request failed: ${detail.slice(0, 300)}`);
  }

  const body = await response.json() as {
    candidates?: Array<{content?: {parts?: Array<{text?: string}>}}>;
  };
  const text = body.candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("").trim();
  if (!text) throw new HttpsError("internal", "The AI returned an empty response.");
  return text;
}

function parseJson<T>(text: string): T {
  const cleaned = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw new HttpsError("internal", "The AI response was not valid JSON.");
  }
}

export const recognizeFridge = onCall(
  {region, secrets: [geminiApiKey], enforceAppCheck: true, timeoutSeconds: 60, memory: "512MiB"},
  async (request) => {
    requireUser(request.auth);
    const imageBase64 = String(request.data?.imageBase64 ?? "");
    if (!imageBase64 || imageBase64.length > 14_000_000) {
      throw new HttpsError("invalid-argument", "A JPEG image under 10 MB is required.");
    }

    const prompt = `Identify visible food products in this fridge photo. Return only JSON in this exact shape:
{"foods":[{"name":"string","category":"dairy|meat|vegetables|fruits|drinks|frozen|pantry|snacks|condiments","confidence":0.0}]}
Do not invent hidden items. Use generic product names when packaging text is unclear. Maximum 25 items.`;

    const text = await callGemini([
      {text: prompt},
      {inlineData: {mimeType: "image/jpeg", data: imageBase64}},
    ], true);
    return parseJson<{foods: unknown[]}>(text);
  },
);

export const generateRecipes = onCall(
  {region, secrets: [geminiApiKey], enforceAppCheck: true, timeoutSeconds: 60, memory: "512MiB"},
  async (request) => {
    requireUser(request.auth);
    const inventory = Array.isArray(request.data?.inventory) ? request.data.inventory.slice(0, 100) : [];
    const filters = Array.isArray(request.data?.filters) ? request.data.filters.slice(0, 10) : [];
    if (inventory.length === 0) throw new HttpsError("invalid-argument", "Inventory is empty.");

    const prompt = `Create 4 practical recipes using this inventory: ${JSON.stringify(inventory)}.
Prioritize foods with the nearest expirationDate. Respect every filter: ${JSON.stringify(filters)}.
Return only JSON with this exact shape:
{"recipes":[{"id":"slug","title":"string","description":"string","minutes":25,"ingredients":["string"],"missingIngredients":["string"],"instructions":["string"],"tags":["Vegetarian","Vegan","Gluten-free","High protein","Low carb","Under 30 minutes"],"proteinGrams":30}]}
Only include tags that truly apply. Missing ingredients must be short shopping-list items.`;

    return parseJson<{recipes: unknown[]}>(await callGemini([{text: prompt}], true));
  },
);

export const askFridgeAssistant = onCall(
  {region, secrets: [geminiApiKey], enforceAppCheck: true, timeoutSeconds: 45, memory: "256MiB"},
  async (request) => {
    requireUser(request.auth);
    const prompt = String(request.data?.prompt ?? "").trim();
    const inventory = Array.isArray(request.data?.inventory) ? request.data.inventory.slice(0, 100) : [];
    if (!prompt) throw new HttpsError("invalid-argument", "A question is required.");

    const system = `You are a concise food-waste assistant. Use the user's real inventory and expiration dates. Never claim an ingredient is available when it is not. Give safe food handling advice and recommend discarding visibly spoiled food. Inventory: ${JSON.stringify(inventory)}. User: ${prompt}`;
    const answer = await callGemini([{text: system}]);
    return {answer};
  },
);

export const sendExpirationNotifications = onSchedule(
  {region, schedule: "every day 08:00", timeZone: "Europe/Berlin", timeoutSeconds: 540, memory: "512MiB"},
  async () => {
    const db = getFirestore();
    const offsets = [0, 1, 3];

    for (const offset of offsets) {
      const date = new Date();
      date.setUTCHours(0, 0, 0, 0);
      date.setUTCDate(date.getUTCDate() + offset);
      const next = new Date(date);
      next.setUTCDate(next.getUTCDate() + 1);

      const snapshot = await db.collectionGroup("inventory")
        .where("expirationDate", ">=", Timestamp.fromDate(date))
        .where("expirationDate", "<", Timestamp.fromDate(next))
        .get();

      const byUser = new Map<string, string[]>();
      for (const doc of snapshot.docs) {
        const userRef = doc.ref.parent.parent;
        if (!userRef) continue;
        const names = byUser.get(userRef.id) ?? [];
        names.push(String(doc.data().name ?? "Food"));
        byUser.set(userRef.id, names);
      }

      for (const [uid, names] of byUser) {
        const user = await db.collection("users").doc(uid).get();
        const data = user.data() ?? {};
        const preferences = data.notificationPreferences as Record<string, boolean> | undefined;
        const preferenceKey = offset === 0 ? "today" : offset === 1 ? "tomorrow" : "threeDays";
        if (preferences?.[preferenceKey] === false) continue;
        const tokens = Array.isArray(data.fcmTokens) ? data.fcmTokens.filter((token): token is string => typeof token === "string") : [];
        if (tokens.length === 0) continue;

        const when = offset === 0 ? "today" : offset === 1 ? "tomorrow" : "in 3 days";
        await getMessaging().sendEachForMulticast({
          tokens: tokens.slice(0, 500),
          notification: {
            title: `${names.length} item${names.length === 1 ? "" : "s"} expire ${when}`,
            body: names.slice(0, 4).join(", ") + (names.length > 4 ? "…" : ""),
          },
          data: {route: "/inventory", expirationOffset: String(offset)},
          android: {priority: "high", notification: {channelId: "expiration_alerts"}},
          apns: {payload: {aps: {sound: "default"}}},
        });
      }
    }
  },
);
