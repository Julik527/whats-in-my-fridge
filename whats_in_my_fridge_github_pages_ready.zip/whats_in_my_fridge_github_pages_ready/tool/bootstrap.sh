#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is not installed or not available in PATH." >&2
  exit 1
fi

flutter create . --platforms=android,ios
flutter pub get

echo
echo "Base project generated. Next:"
echo "  1. Run: flutterfire configure"
echo "  2. Enable Email/Password, Google, and Apple providers in Firebase Auth"
echo "  3. Run: flutter analyze && flutter test"
